package GUI;

public enum SpriteType {
  BLOCK,
  DIRT,
  BACKGROUND,
  BRICK,
  COIN,
  PLAYER,
  GATE
}
