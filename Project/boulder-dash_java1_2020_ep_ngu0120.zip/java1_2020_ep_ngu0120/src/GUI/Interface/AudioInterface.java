package GUI.Interface;

import java.io.File;

public interface AudioInterface {
  public void Sound(File Sound, float gain);

}
