package Main;

import java.io.IOException;

import ControlInput.Launcher;

public class Main {
  public static void main(String[] args) throws IOException {
    new Launcher();
  }
}
