package LauchMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadMap extends Launch {

  public ReadMap(int level, String name) {
    super(level, name);
  }

  public void setMap(int level, char[][] tab) throws FileNotFoundException {
    String filePath = null;
    switch (level) {
      case 1:
        filePath = "image/Level 1.txt";
        break;
      case 2:
        filePath = "image/Level 2.txt";
        break;
      case 3:
        filePath = "image/Level 3.txt";
        break;
    }
    Scanner scan = new Scanner(new File(filePath));
    int row = 0;
    String line;
    char[] charLine;
    while (scan.hasNext()) {
      line = scan.next();
      charLine = line.toCharArray();
      for (int col = 0; col < line.length(); col++) {
        tab[row][col] = charLine[col];
      }
      row++;
    }

  }
}
