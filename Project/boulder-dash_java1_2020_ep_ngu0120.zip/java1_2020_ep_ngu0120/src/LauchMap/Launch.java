package LauchMap;

import java.io.FileNotFoundException;

public class Launch {
  protected int level = 0;
  protected char tab[][] = new char[22][40];
  protected String name = "";
  protected ReadMap map;

  public Launch(int level, String name) {
    this.level = level;
    this.name = name;
  }

  public void launch() throws FileNotFoundException {
    this.map = new ReadMap(this.level, this.name);
    this.map.setMap(this.level, this.tab);
  }

  public char[][] getTab() {
    return this.tab;
  }

}
