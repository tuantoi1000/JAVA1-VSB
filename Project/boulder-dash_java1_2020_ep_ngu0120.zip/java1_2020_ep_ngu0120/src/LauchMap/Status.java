package LauchMap;

public enum Status {
  BLOCKING,
  THROUGH
}
