package LauchMap;

public enum PlayerMove {
  UP,
  RIGHT,
  DOWN,
  LEFT
}
