package ControlInput.ControlInputInterface;

import LauchMap.PlayerMove;

public interface ControlInterface {
  public void setControl(final PlayerMove player);

}
